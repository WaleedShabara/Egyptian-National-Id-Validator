var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./NationalIdValidator/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./NationalIdValidator/NationalIdValidator.ts":
/*!****************************************************!*\
  !*** ./NationalIdValidator/NationalIdValidator.ts ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.NationalIdValidator = void 0;\n\nvar NationalIdValidator =\n/** @class */\nfunction () {\n  function NationalIdValidator() {}\n\n  NationalIdValidator.prototype.validateNid = function (nid) {\n    var pattern = /^(2|3)[0-9][0-9][0-1][0-9][0-3][0-9](01|02|03|04|05|06|11|12|13|14|15|16|17|18|19|21|22|23|24|25|26|27|28|29|31|32|33|34|35|88)\\d\\d\\d\\d\\d$/;\n    var result = pattern.test(nid);\n\n    if (result) {\n      for (var a = nid.substring(13, 14), n = nid.substring(0, 13), i = 0, u = n.length - 1, l = 2; u >= 0;) 8 == l && (l = 2), i += l * parseInt(n.substring(u, u + 1)), u -= 1, l += 1;\n\n      var f = 11 - i % 11;\n\n      if (f > 9) {\n        f -= 10;\n      }\n\n      ;\n      result = parseInt(a) == f;\n    }\n\n    return result;\n  };\n\n  return NationalIdValidator;\n}();\n\nexports.NationalIdValidator = NationalIdValidator;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NationalIdValidator/NationalIdValidator.ts?");

/***/ }),

/***/ "./NationalIdValidator/index.ts":
/*!**************************************!*\
  !*** ./NationalIdValidator/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.NationalId = void 0;\n\nvar NationalIdValidator_1 = __webpack_require__(/*! ./NationalIdValidator */ \"./NationalIdValidator/NationalIdValidator.ts\");\n\nvar NationalId =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function NationalId() {\n    this._validador = new NationalIdValidator_1.NationalIdValidator();\n  }\n  /**\r\n   * Get UniqueId so as to avoid id conflict between multiple fields bind to same attribute\r\n   * @param context The \"Input Properties\" containing the parameters, control metadata and interface functions.\r\n   * @param passInString input string as suffix\r\n   * @param randomInt random integer\r\n   * @returns a string of uniqueId includes attribute logicalname + passIn specialized string + random Integer\r\n  */\n\n\n  NationalId.prototype.createUniqueId = function (context, passInString) {\n    var randomInt = Math.floor(Math.floor(100) * Math.random());\n    return context.parameters.NationalIdValue.attributes.LogicalName + \"-\" + passInString + randomInt;\n  };\n\n  NationalId.prototype.renderControl = function (container) {\n    this._container = document.createElement(\"div\");\n    this._inputControl = document.createElement(\"input\");\n\n    this._inputControl.setAttribute(\"id\", this.createUniqueId(this._context, \"natid_control\"));\n\n    this._inputControl.setAttribute(\"value\", this._context.parameters.NationalIdValue.formatted ? this._context.parameters.NationalIdValue.formatted : \"\");\n\n    this._inputControl.addEventListener(\"input\", this._refreshData);\n\n    this._spanControl = document.createElement(\"span\");\n    this._iconControl = document.createElement(\"i\");\n\n    this._iconControl.classList.add(\"fas\");\n\n    this._spanControl.appendChild(this._iconControl);\n\n    this._container.appendChild(this._inputControl);\n\n    this._container.appendChild(this._spanControl);\n\n    container.appendChild(this._container);\n  };\n\n  NationalId.prototype.refreshData = function (evt) {\n    this._nid = this._inputControl.value;\n\n    if (this._nid === \"\" || this._nid === undefined) {\n      this._iconControl.classList.remove(\"control-valid\");\n\n      this._iconControl.classList.remove(\"fa-check-circle\");\n\n      this._iconControl.classList.remove(\"fa-times-circle\");\n\n      this._iconControl.classList.remove(\"control-invalid\");\n    } else this.validateField();\n\n    this._notifyOutputChanged();\n  };\n\n  NationalId.prototype.validateField = function () {\n    if (this._nid !== \"\" && this._nid !== undefined) {\n      if (this._validador.validateNid(this._nid)) //this._validador.isCNPJ(this._nid)  && \n        {\n          console.log('Valid National ID');\n\n          this._iconControl.classList.remove(\"control-invalid\");\n\n          this._iconControl.classList.remove(\"fa-times-circle\");\n\n          this._iconControl.classList.add(\"fa-check-circle\");\n\n          this._iconControl.classList.add(\"control-valid\");\n        } else {\n        this._nid = \"\";\n        console.log('Invalid National Id');\n\n        this._iconControl.classList.remove(\"control-valid\");\n\n        this._iconControl.classList.remove(\"fa-check-circle\");\n\n        this._iconControl.classList.add(\"fa-times-circle\");\n\n        this._iconControl.classList.add(\"control-invalid\");\n      }\n    }\n  };\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='starndard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  NationalId.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._container = document.createElement(\"div\");\n    this._context = context;\n    this._refreshData = this.refreshData.bind(this);\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._nid = context.parameters.NationalIdValue.formatted ? context.parameters.NationalIdValue.formatted : \"\";\n    this.renderControl(container);\n    if (this._nid !== \"\" && this._nid !== undefined) this.validateField();\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  NationalId.prototype.updateView = function (context) {\n    // Add code to update control view\n    this._nid = context.parameters.NationalIdValue.raw ? context.parameters.NationalIdValue.raw : \"\";\n    this._context = context; //this.validateField();\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  NationalId.prototype.getOutputs = function () {\n    return {\n      NationalIdValue: this._nid\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  NationalId.prototype.destroy = function () {\n    // Add code to cleanup control if necessary\n    this._inputControl.removeEventListener(\"input\", this._refreshData);\n  };\n\n  return NationalId;\n}();\n\nexports.NationalId = NationalId;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NationalIdValidator/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Linkdev.NationalId', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NationalId);
} else {
	var Linkdev = Linkdev || {};
	Linkdev.NationalId = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NationalId;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}