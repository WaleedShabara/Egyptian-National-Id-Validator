var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./NationalIdValidator/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./NationalIdValidator/NationalIdValidator.ts":
/*!****************************************************!*\
  !*** ./NationalIdValidator/NationalIdValidator.ts ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.NationalIdValidator = exports.Gender = void 0;\nvar Gender;\n\n(function (Gender) {\n  Gender[Gender[\"Male\"] = 1] = \"Male\";\n  Gender[Gender[\"Female\"] = 2] = \"Female\";\n})(Gender = exports.Gender || (exports.Gender = {}));\n\nvar NationalIdValidator =\n/** @class */\nfunction () {\n  function NationalIdValidator() {}\n\n  NationalIdValidator.prototype.validateNid = function (nid) {\n    var pattern = /^(2|3)[0-9][0-9][0-1][0-9][0-3][0-9](01|02|03|04|05|06|11|12|13|14|15|16|17|18|19|21|22|23|24|25|26|27|28|29|31|32|33|34|35|88)\\d\\d\\d\\d\\d$/;\n    var result = pattern.test(nid);\n\n    if (result) {\n      for (var a = nid.substring(13, 14), n = nid.substring(0, 13), i = 0, u = n.length - 1, l = 2; u >= 0;) 8 == l && (l = 2), i += l * parseInt(n.substring(u, u + 1)), u -= 1, l += 1;\n\n      var f = 11 - i % 11;\n\n      if (f > 9) {\n        f -= 10;\n      }\n\n      ;\n      result = parseInt(a) == f;\n    }\n\n    return result;\n  };\n\n  NationalIdValidator.prototype.getGenderFromNid = function (nid) {\n    var genderIdentifiernid = nid.substr(12, 1);\n    var result = +genderIdentifiernid;\n    if (result % 2 == 0) return Gender.Female;else return Gender.Male;\n  };\n\n  NationalIdValidator.prototype.getBirthDateFromNid = function (nid) {\n    var result = nid.substr(0, 1) == \"2\" ? \"19\" : \"20\";\n    result += nid.substr(1, 2) + \"-\";\n    result += nid.substr(3, 2) + \"-\";\n    result += nid.substr(5, 2) + \"T00:00:00\";\n    return result;\n  };\n\n  return NationalIdValidator;\n}();\n\nexports.NationalIdValidator = NationalIdValidator;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NationalIdValidator/NationalIdValidator.ts?");

/***/ }),

/***/ "./NationalIdValidator/index.ts":
/*!**************************************!*\
  !*** ./NationalIdValidator/index.ts ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.NationalId = void 0;\n\nvar NationalIdValidator_1 = __webpack_require__(/*! ./NationalIdValidator */ \"./NationalIdValidator/NationalIdValidator.ts\");\n\nvar NationalId =\n/** @class */\nfunction () {\n  function NationalId() {\n    this._validator = new NationalIdValidator_1.NationalIdValidator();\n  }\n\n  NationalId.prototype.createUniqueId = function (context, passInString) {\n    var randomInt = Math.floor(Math.floor(100) * Math.random());\n    return context.parameters.NationalIdValue.attributes.LogicalName + \"-\" + passInString + randomInt;\n  };\n\n  NationalId.prototype.renderControl = function (container) {\n    this._container = document.createElement(\"div\");\n    this._inputControl = document.createElement(\"input\");\n\n    this._inputControl.setAttribute(\"id\", this.createUniqueId(this._context, \"natid_control\"));\n\n    this._inputControl.setAttribute(\"value\", this._context.parameters.NationalIdValue.formatted ? this._context.parameters.NationalIdValue.formatted : \"\");\n\n    this._inputControl.addEventListener(\"input\", this._refreshData);\n\n    this._spanControl = document.createElement(\"span\");\n    this._iconControl = document.createElement(\"i\");\n\n    this._iconControl.classList.add(\"fas\");\n\n    this._spanControl.appendChild(this._iconControl);\n\n    this._container.appendChild(this._inputControl);\n\n    this._container.appendChild(this._spanControl);\n\n    container.appendChild(this._container);\n  };\n\n  NationalId.prototype.refreshData = function (evt) {\n    this._nid = this._inputControl.value;\n\n    if (this._nid === \"\" || this._nid === undefined) {\n      this._iconControl.classList.remove(\"control-valid\");\n\n      this._iconControl.classList.remove(\"fa-check-circle\");\n\n      this._iconControl.classList.remove(\"fa-times-circle\");\n\n      this._iconControl.classList.remove(\"control-invalid\");\n    } else this.validateField();\n\n    this._notifyOutputChanged();\n  };\n\n  NationalId.prototype.validateField = function () {\n    if (this._nid !== \"\" && this._nid !== undefined) {\n      if (this._validator.validateNid(this._nid)) {\n        console.log('Valid National ID');\n        this._birthdate = new Date(this._validator.getBirthDateFromNid(this._nid));\n        console.log(this._birthdate);\n        this._gender = this._validator.getGenderFromNid(this._nid);\n        console.log(this._gender);\n\n        this._iconControl.classList.remove(\"control-invalid\");\n\n        this._iconControl.classList.remove(\"fa-times-circle\");\n\n        this._iconControl.classList.add(\"fa-check-circle\");\n\n        this._iconControl.classList.add(\"control-valid\");\n      } else {\n        this._nid = \"\";\n        this._birthdate = undefined;\n        this._gender = undefined;\n        console.log('Invalid National Id');\n\n        this._iconControl.classList.remove(\"control-valid\");\n\n        this._iconControl.classList.remove(\"fa-check-circle\");\n\n        this._iconControl.classList.add(\"fa-times-circle\");\n\n        this._iconControl.classList.add(\"control-invalid\");\n      }\n    }\n  };\n\n  NationalId.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this._container = document.createElement(\"div\");\n    this._context = context;\n    this._refreshData = this.refreshData.bind(this);\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._nid = context.parameters.NationalIdValue.formatted ? context.parameters.NationalIdValue.formatted : \"\";\n    this.renderControl(container);\n    if (this._nid !== \"\" && this._nid !== undefined) this.validateField();\n  };\n\n  NationalId.prototype.updateView = function (context) {\n    this._nid = context.parameters.NationalIdValue.raw ? context.parameters.NationalIdValue.raw : \"\";\n    this._context = context;\n  };\n\n  NationalId.prototype.getOutputs = function () {\n    return {\n      NationalIdValue: this._nid,\n      BirthdateValue: this._birthdate,\n      GenderValue: this._gender\n    };\n  };\n\n  NationalId.prototype.destroy = function () {\n    this._inputControl.removeEventListener(\"input\", this._refreshData);\n  };\n\n  return NationalId;\n}();\n\nexports.NationalId = NationalId;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./NationalIdValidator/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('WAR.NationalId', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NationalId);
} else {
	var WAR = WAR || {};
	WAR.NationalId = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.NationalId;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}